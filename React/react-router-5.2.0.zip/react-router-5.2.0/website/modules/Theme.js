export const RED = "hsl(0, 78%, 60%)";
export const DARK_GRAY = "hsl(0, 0%, 14.5%)";
export const LIGHT_GRAY = "hsl(0, 0%, 32%)";
export const BRIGHT_GRAY = "hsl(0, 0%, 78%)";
export const SMALL_SCREEN = "(max-width: 600px)";
