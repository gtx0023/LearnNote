---
name: "\U0001F914Support/Usage Question"
about: For usage questions, please use Stack Overflow or Reactiflux!
---

This is a bug tracker, not a support system. For usage questions, please use Stack Overflow or Reactiflux where there are a lot more people ready to help you out. Thanks!

https://stackoverflow.com/questions/tagged/react-router  
https://www.reactiflux.com/
