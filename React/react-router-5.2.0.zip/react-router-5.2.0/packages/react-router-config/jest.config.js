module.exports = { preset: "../../jest-preset.js" };
