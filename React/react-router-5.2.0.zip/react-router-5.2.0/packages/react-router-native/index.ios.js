import { AppRegistry } from "react-native";

import ReactRouterNative from "./examples/BasicExample.js";
//import ReactRouterNative from './examples/ExperimentalExample'

AppRegistry.registerComponent("ReactRouterNative", () => ReactRouterNative);

export default ReactRouterNative;
