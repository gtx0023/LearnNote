# Deep Linking

Before you can use `<DeepLinking/>` you need to set it up in your native app configuration. Please refer to the [React Native Docs](https://facebook.github.io/react-native/docs/linking.html).

We'll have a simpler guide here soon.
