"use strict";
require("./warnAboutDeprecatedCJSRequire")("StaticRouter");
module.exports = require("./index.js").StaticRouter;
