# &lt;MemoryRouter>

Re-exported from core [`MemoryRouter`](../../../react-router/docs/api/MemoryRouter.md)
