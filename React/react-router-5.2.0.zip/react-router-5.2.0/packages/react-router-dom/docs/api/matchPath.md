# matchPath

Re-exported from core [`matchPath`](../../../react-router/docs/api/matchPath.md)
