# &lt;Route>

Re-exported from core [`Route`](../../../react-router/docs/api/Route.md)
