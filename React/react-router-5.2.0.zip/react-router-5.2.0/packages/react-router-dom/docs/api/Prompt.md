# &lt;Prompt>

Re-exported from core [`Prompt`](../../../react-router/docs/api/Prompt.md)
