# &lt;Router>

Re-exported from core [`Router`](../../../react-router/docs/api/Router.md)
