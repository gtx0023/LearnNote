# &lt;StaticRouter>

Re-exported from core [`StaticRouter`](../../../react-router/docs/api/StaticRouter.md)
