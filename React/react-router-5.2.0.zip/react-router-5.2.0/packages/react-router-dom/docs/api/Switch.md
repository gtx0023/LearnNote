# &lt;Switch>

Re-exported from core [`Switch`](../../../react-router/docs/api/Switch.md)
