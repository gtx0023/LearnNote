# withRouter

Re-exported from core [`withRouter`](../../../react-router/docs/api/withRouter.md)
