# &lt;Redirect>

Re-exported from core [`Redirect`](../../../react-router/docs/api/Redirect.md)
