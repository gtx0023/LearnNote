"use strict";
require("./warnAboutDeprecatedCJSRequire")("Route");
module.exports = require("./index.js").Route;
