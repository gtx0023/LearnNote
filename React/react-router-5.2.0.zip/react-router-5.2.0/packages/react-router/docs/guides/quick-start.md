# Quick Start

You probably want to read one of these instead:

- [Web Quick Start](../../../react-router-dom/docs/guides/quick-start.md)
- [Native Quick Start](../../../react-router-native/docs/guides/quick-start.md)

## Installation

React Router Core is published to [npm](https://npm.im/react-router) so you can install it with either `npm` or [`yarn`](https://yarnpkg.com).

```sh
npm install react-router
# or
yarn add react-router
```
